﻿namespace ObjectSripterWinCA.Source.Values
{
    /*
    internal class AppConstants
    {
        internal const string Type = ":PTYPENAME";
        internal const string Owner = ":POWNER";
        internal const string Name = ":PNAME";
    }
    */
}
